
<?php 
session_start();
    require_once 'config.php';
    
//Объявляем ячейку для добавления ошибок, которые могут возникнуть при обработке формы.
$_SESSION["error_messages"] = '';

//Объявляем ячейку для добавления успешных сообщений
$_SESSION["success_messages"] = '';
  function clear_data($val){
    $val = trim($val);
    $val = stripslashes($val);
    $val = strip_tags($val);
    $val = htmlspecialchars($val);
    return $val;

  }
    $username = clear_data($_POST['username']);
    $email = clear_data($_POST['email']);
    $password = clear_data($_POST['password']);
    $password_confirm = clear_data($_POST['password_confirm']);

    $pattern_username = '/^.*[^A - z].*$';
    $err=[];
    $flag = 0;
    
    if($_SERVER['REQUEST_METHOD']=='POST'){
        if(preg_match($pattern_username,$username)){
            $err['username'] = "<small class='text-danger'>Здесь только латинские буквы </small>";
            $flag = 1;
        }
        if(mb_strlen($username)>10 || empty($username)){
            $err['username'] = "<small class='text-danger'>Имя не должно быть более 10 символов</small>";
            $flag = 1;

        }
    }
    $required_fields = ['email', 'password', 'login'];
    $errors = [];

    foreach ($required_fields as $field) {
        if (empty($_POST[$field])) {
         $errors[$field] = 'Поле не заполнено';
    }
}

if (count($errors)) {
    // показать ошибку валидации
}
    if($password === $password_confirm){
        
        $path = 'uploads/' . time() .  $_FILES['avatar'] ['name']; ;
        if(!move_uploaded_file( $_FILES['avatar'] ['tmp_name'] ,$path)){
            $_SESSION['message'] = 'Ощибка при загрузке сообщения';
            header('Location : ../register.php');
        }
        
        mysqli_query($connect, query:"INSERT INTO `tb_user` (`id`, `username`, `email`, `password`, `avatar`) VALUES (NULL, $username, $email, $password, $path)");
        $_SESSION['message'] = 'Регистрация прошла успешно';
        header('Location : ../index.php');
    }else{
        $_SESSION['message'] = 'Пароли не совподают';
        header('Location : ../register.php');
    }
    if(isset($_POST['submit'])){
        if(!empty($required_fields)){
            echo 'Заполните все поля';
            header('Location: ../feed.php');
        }

    }

    if(isset($_POST['submit']))$mypwd = "";
    if(isset($_POST['submit']))$hash = password_hash($mypwd, PASSWORD_DEFAULT);
    if(isset($_POST['submit']))var_dump($hash);

    if(isset($_POST['submit']))$verifyPwd = password_verify($mypwd, $hash);
    if(isset($_POST['submit']))var_dump($verifyPwd);
