<?php
    if(isset($_POST['video'])) {

        $text = $_POST['video'];
        echo "video link:" . $text . "<br>";
        $text = preg_replace("#.*youtube.com/watch\?v=#","",$text);
        echo "the video Id:" .$text. "<br>";
        
    }
    session_start();
    
    function form_submitted($form_name=false){
        if(!isset($_POST['submitted'])){ // был ли вообще сабмит
          return false; //неа, завершаем
        }
        if($form_name && $_POST['submitted']!=$form_name){ //если проверяется конкретная форма, была ли отправлена именно она?
          return false;//нет, завершаем
        }
        return true;//все, ок.
      }
    
    ?>