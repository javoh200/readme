<?php

include('config.php');


if(!empty($_FILES('file'))){

  $file = $_FILES['file'];
  $name = $file['file'];
  $pathFile = __DIR__ .'/img/'.$name;
  $pathQuery = "INSERT INTO posts ( path)
  VALUES('$path')";
}

if(!move_uploaded_file($file['tmp_name'],$pathFile)){
  echo 'Файл не смог загрузится';
  
  header('Location: ./adding-post.php');

}
?>